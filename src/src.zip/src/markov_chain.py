#from dict_to_df import option_df
import pandas as pd
from random import randint
##option_df- creates a dictionary and for each note stores  a list of tuples containing the
#the next note and its probability, this function will be used for the function predict_next_note
def option_df(prob_df):
    #print(prob_df)
    note_option = {}
    for key,row in prob_df.iterrows():
        temp_array= list()
        #print(key)
        for el in row.iteritems():
            if el[1] > 0:
                temp_array.append(tuple((el[0],el[1])))
        note_option[key] = temp_array
    return note_option
#make the dictionary
#option_dict = option_df()

#takes as input on note a generate the note with the highest probability to appear next from the option_dict
def predict_next_note(input_note,option_dict):
    highest_prob = tuple((0,0))
    if input_note in option_dict:
        #note tuple contains (note,probability)
        for note_tuple in option_dict[input_note]:
            #print(note_tuple[1])
            if note_tuple[1] > highest_prob[1]:
                highest_prob = note_tuple
    return highest_prob[0]


#given a sequence_length we want to generate a list of notes with size sequence_length by calling predict_next_note
#function sequence_length times by updating the input of the predict_next_note function
def predict_sequence(sequence_length,option_dict):
    ##random generate a note
    random_note = randint(23,100)
    generated_notes = list()
    input_note = random_note
    for n in range (sequence_length):
        print('the note prediction ',predict_next_note(input_note,option_dict), 'for note ', input_note)
        generated_notes.append(predict_next_note(input_note,option_dict))
        input_note = generated_notes[len(generated_notes)-1]
    return generated_notes

def init_markov_model(prob_df):
    option_dict = option_df(prob_df)
    print(option_dict)
    print(predict_sequence(100,option_dict))
