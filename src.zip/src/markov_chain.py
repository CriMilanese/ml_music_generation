#from dict_to_df import option_df
import pandas as pd
from random import randint,random
import numpy as np
from mido import Message, MidiFile, MidiTrack
##option_df- creates a dictionary and for each note stores  a list of tuples containing the
#the next note and its probability, this function will be used for the function predict_next_note
def option_df(prob_df):
    note_option = {}
    for key,row in prob_df.iterrows():
        temp_array= list()
        for el in row.iteritems():
            if el[1] > 0:
                temp_array.append(tuple((el[0],el[1])))
        temp_array = sorted(temp_array, key=lambda x: x[1], reverse= True)
        note_option[key] = temp_array
    return note_option


def find_next_note_in_sequence(generated_notes):
    note_tuple = generated_notes[-2:]
    print(note_tuple)
    tuple_count = bigram_dict[tuple((note_tuple))]
    high_prob = 0
    next_note = 0
    note_tuple.append(0)
    for temp_note in range (0,127):
        note_tuple[2] = temp_note
        temp_trigram = note_tuple
        if tuple(temp_trigram) not in trigram_dict:
            continue
        trigram_count = trigram_dict[tuple((temp_trigram))]
        temp_prob = trigram_count/ tuple_count
        #here we have to add a probabilities conditions to break loop repeation for some trigrams
        if temp_prob > high_prob:
            high_prob = temp_prob
            next_note = temp_note
        print(next_note)
    return next_note

#takes as input on note a generate the note with the highest probability to appear next from the option_dict
def predict_next_note(input_note,option_dict,generated_notes):
    #print(bigram_dict)
    #print(tri)
    highest_prob = tuple((0,0))
    if input_note in option_dict:
        #note tuple contains (note,probability)
        if len(generated_notes) <  2 :
            print(option_dict[input_note])
            highest_prob = option_dict[input_note][0]
        else:
            #add a randomizer based on prob
             print('best note for trigram', find_next_note_in_sequence(generated_notes))
             return find_next_note_in_sequence(generated_notes)
    return highest_prob[0]


#given a sequence_length we want to generate a list of notes with size sequence_length by calling predict_next_note
#function sequence_length times by updating the input of the predict_next_note function
def predict_sequence(sequence_length,option_dict):
    ##random generate a note
    random_note = randint(23,100)
    while not bool(option_dict[random_note]):
        random_note = randint(23,100)
    generated_notes = list()
    input_note = random_note
    generated_notes.append(random_note)
    for n in range (sequence_length):
        print('this is the generate notes', generated_notes)
        #print('the note prediction ',predict_next_note(input_note,option_dict), 'for note ', input_note)
        generated_notes.append(predict_next_note(input_note,option_dict,generated_notes))
        input_note = generated_notes[len(generated_notes)-1]
    return generated_notes



file_notes = []
bigram_dict = {}
trigram_dict = {}

def n_grams_frequency(dt):
    file_notes.append(dt)
    for notes in file_notes:
        for index,el in enumerate(notes):
            if index+1 < len(notes):
                if bool(bigram_dict):
                    if tuple((el,notes[index+1])) not in bigram_dict.keys():
                                bigram_dict[tuple((el,notes[index+1]))]= 1
                    else:
                        bigram_dict[tuple((el,notes[index+1]))] += 1
                else:
                    bigram_dict[tuple((el,notes[index+1]))] = 1
                #print(bigram_dict)

    for notes in file_notes:
        for index,el in enumerate(notes):
            if index+2 < len(notes):
                if tuple((el,notes[index+1],notes[index+2])) not in trigram_dict.keys():
                            trigram_dict[tuple((el,notes[index+1],notes[index+2]))]= 1
                else:
                    trigram_dict[tuple((el,notes[index+1],notes[index+2]))] += 1

def playback(generated_notes):
    mid = MidiFile()
    track = MidiTrack()
    mid.tracks.append(track)
    track.append(Message('program_change', program=12, time=0))
    for notes in generated_notes:
        track.append(Message('note_on', note=notes, velocity=100, time=300))
        track.append(Message('note_off', note=notes, velocity=127, time=300))
    mid.save('new_song.mid')


def init_markov_model(prob_df):
    option_dict = option_df(prob_df)
    print(predict_sequence(200,option_dict))
    playback(predict_sequence(200,option_dict))
