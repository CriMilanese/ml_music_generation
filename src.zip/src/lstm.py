from dict_to_df import dict_to_dataframe

import keras
from keras.model import Sequential
from keras.layers import LSTM,Dense,Dropout,Activation


def init_model(input_df):
    ## the shape of the matrix is 128 by 128
    
