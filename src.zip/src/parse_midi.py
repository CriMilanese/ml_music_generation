# main functions:
    # parse MIDI file

#from MIDI import MIDIFile

from re import findall
from sys import argv
from mido import MidiFile
from mido import Message,MetaMessage
import numpy as np
from markov_chain import n_grams_frequency
from markov_chain import init_markov_model
from dict_to_df import dict_to_dataframe, calc_probability




def check(file):
    mid = MidiFile(file)
    #for track in mid.tracks:
    counter = 0
    for msg in mid.tracks[0]:
        counter +=1
        if msg.type == 'time_signature':
            print(msg)
            #print(meta)

            #if msg.type == 'note_on':

                #print(msg)




def parse(file):
    mid=MidiFile(file)
    notes = []
    for track in mid.tracks:
        for msg in track:
            if msg.type == 'note_on':
                notes.append(msg.note)
        del track
    n_grams_frequency(notes)
    my_dict = {}
    for indx, n in enumerate(notes):
        if indx+1 < len(notes):
            # add each new note to the list and append
            # the following note to the followers list
            if n not in my_dict.keys():
                my_dict[n] = np.zeros(128, dtype= int)
                my_dict[n][notes[indx+1]] = 1
            else:
                my_dict[n][notes[indx+1]] += 1

    for note in my_dict.keys():
        #print(note , ': ')
        counter= 0
        for foll in my_dict[note]:
            #if foll != 0.0:
                #print(foll, 'for key note ',note,'at counter',counter)
            counter += 1
    del notes
    #temp_df = dict_to_dataframe(my_dict)
    #prob_table = calc_probability(temp_df)
    #init_markov_model(prob_table)
    return my_dict
#parse(argv[1])
#check(argv[1])
